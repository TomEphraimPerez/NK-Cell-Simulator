//  Virus.cpp
//  CTL_dyn_5
//
//  Created by Thomas Perez on 4/13/15.
//  Copyright (c) 2015 Thomas Perez. All rights reserved.
//

#include "Virus.h"
#include "Cell.h"

Virus::Virus(){

    for (int i=1; i<MAX_ROWS; ++i) {
        for (int j=1; j<MAX_COLS; ++j) {
            cell[i][j] = NULL;                            // *cell is of type Entity and a pointer var.
        }
    }
    /**
     Attributes;

     Pathway (Classical vs CD4-APC-CTL)  PW_C  vs PW_APC
     APC population                      y     (p61)
     APC reaction constants              y_rc


     //  PathWay CD4_APC_CTL . (cytokines; viz IL2).
     PW_CD4_APC(0.1);                            // For every unit of virus/virus_load (V_ld), z is returned.
     */                                               // ( CTL proliferation , p62 ).

}



void Virus::Die(){}



float Virus::PW_CD4_APC( float vir ){              // PathWay CD4_APC_CTL . (cytokines; viz IL2).
    int z=0;
    z = 0.5 * vir / 1.5;                           // same a x/3 (or vir/3), the formal equation simplifies to this, (ch_2).

    return z;                                      // CTL proliferation  rate. (.. is 1/3 the num of virus particles).
}


float Virus::PW_C( float vir ){                     // PathWay Classical . (receptor ligands; viz CD40-CD40L or B7-CD28).
    int z=0;
    z = 2 * powf( vir, 2 ) / ( 1 + vir );           // (2*x^2) / ( 1 + x )

    return z;                                       // CTL proliferation rate.  0,2, 2 2/3, 4 1/2, 6 1/3 ...

}




