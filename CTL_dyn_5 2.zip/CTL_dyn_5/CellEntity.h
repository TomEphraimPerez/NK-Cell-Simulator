//  CellEntity.h
//  CTL_dyn_5
//
//  Created by Thomas Perez on 4/13/15.
//  Copyright (c) 2015 Thomas Perez. All rights reserved.

#ifndef __CTL_dyn_5__CellEntity__
#define __CTL_dyn_5__CellEntity__

#include "CONSTANTS.h"

class Entity {


protected:

public:

    Entity* cell[MAX_ROWS][MAX_COLS]; // =============================== <<< - >>>

    Entity();

    Entity(int coord_i, int coord_j, char the_entity);

    Entity(char the_entity);

    void Print();

    char GetEntity( Entity* cell[MAX_ROWS][MAX_COLS] );                 // Access

    void SetEntity(char);                                               // Mute'

    bool isOccupied( int, int );

    int genericRand();
    int betterRand( int, int );

    Entity& operator = (const Entity& eSource);


protected:


private:

    char entity;

    //    float die;
    //    //----------  Virus class
    //    float APCpop;                                // APC population
    //    float T_h;                                   // T_helper_free
    //
    //    float gamma, eta;                            // reaction constants
    //    float c;                                     // net CTL activation reaction const.      AKA CTL_responsiveness.
    //    float epsilon;                               // net APC activation reaction const (p59),
    // or efficacy of help(p60)

};
#endif /* defined(__CTL_dyn_5__CellEntity__) */





