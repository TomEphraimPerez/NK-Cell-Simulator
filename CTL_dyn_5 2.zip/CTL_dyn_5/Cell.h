//  Cell.h
//  CTL_dyn_5
//
//  Created by Thomas Perez on 4/13/15.
//  Copyright (c) 2015 Thomas Perez. All rights reserved.
//

#ifndef __CTL_dyn_5__Cell__
#define __CTL_dyn_5__Cell__

using namespace std;                                  // friend ostream& operator<< . . .
#include <iostream>

#include "CONSTANTS.h"                               // USLEEP
#include "CellEntity.h"
#include "Virus.h"

class Cell : public Entity {

public:

    Cell();

    void Init();

    void ifInfected();

    void ifVirusKilled();                           // Helper

    void Step();

    friend ostream& operator << (ostream& out_stream, const Cell& theCell);//  not used yet 3-5-15
    Cell& operator = (const Entity &eSource);

    virtual void Print();                           // virt
    void PrintAndCountEntities();

    void tissueBoundary();

    void populateWithH_ostCells();                   // 20:80 cells of the organ will be vulnerable to infection.

    // INFECT/INVADE BODY. START IMMUNE RESPONSE.
    // The Woodarz CD4_APC_CTL (linear) Pathway.
    // AFTER ~8 H_ost CELLS SELECTED, -8 + 64 = 56 CELLS UNOCCUPIED.
    // AFTER INIT INFECTION, 3 v_irus CELLS and 1 CTL WILL BE PRESENT
    // ie THERE WILL BE 4 LESS AVAILABLE CELL SITES TO BE OCCUPIABLE.
    void InfectCD4_APC_CTL( int &, int &, int & );     //Call PW_CD4_APC(6); For every 6 v_particles, 2 CTL responds.
    void CTLpopulatesTissueCD4_APC_CTL();

    // INFECT/INVADE BODY. START IMMUNE RESPONSE.
    // The Woodarz Classical (nonlinear) Pathway.
    void InfectClassical( int &, int &, int & );
    void CTLpopulatesTissueClassical();

    void migrate();                                    // Host cells migrate or not. Initiates/provokes virus contamination.
    void randMigrate();

    void deallocate(Entity* cell[][MAX_COLS]);
                                                        // Use a Switch() along with Rand() for RT.LT,Up and DN.
    void Check_moveRT(int x, int y);                    // Repositions a single cell adjacent.
    void Check_moveLT(int x, int y);
    void Check_moveDN(int x, int y);
    void Check_moveUP(int x, int y);

    const void Check_moveSWITCH( int x=0 , int y=0 );

    int genericRand();
    int betterRand( int n_high, int n_low  );



protected:


private:


};




#endif /* defined(__CTL_dyn_5__Cell__) */




