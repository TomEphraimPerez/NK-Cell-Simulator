//  CONSTANTS.h
//  CTL_dyn_5
//
//  Created by Thomas Perez on 4/13/15.
//  Copyright (c) 2015 Thomas Perez. All rights reserved.
//

#ifndef CTL_dyn_5_CONSTANTS_h
#define CTL_dyn_5_CONSTANTS_h

// No class.
const int MAX_ROWS = 10; const int MAX_COLS = 10;
const int tissue_sample_SIZE = MAX_COLS * MAX_ROWS;

const int USLEEP = 300000;       // sleep(s) is in sec only. A good delay is usleep(microsec).



#endif
