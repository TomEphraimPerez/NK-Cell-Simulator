//  MAIN.cpp
//  CTL_dyn_5

//                  T. E. Perez Spr 2015 | CS20 Indy' project | with Prof P. Wilkinson PhD
/**
            ********************************************************************************************
            *                                                                                          *
            *            BEST CASE SCENARIO FOR NK CELL DYNAMICS USING MATHEMATICAL MODELING           *
            *                                                                                          *
            *                            Based on D. Wodarz (et al)                                    *
            *                              ISBN 10: 0-387-30893-8                                      *
            *                           ISBN-13: 978-0-387-30893-7                                     *
            *                                                                                          *
            ********************************************************************************************


 >   PLEASE REFER TO CTL_5 SYNOPSIS FOR DETAILS.
 >   CASE_USE STUDY TBA. DETAILED FEASIBILITY REQUIREMENTS TBA.

    Other than the system requirements brief, a "nuts and bolts" quick synopsis of this project is this;
According to Dominik Woodarz, in his book;
"NK Cell Dynamics - A Mathematical and Computational Appraoch to Immunology",
He presents two theories in the beginning, and expounds on those to extrapolate other theories as well
and expand those initial fundamental theories for a more precise vision of NK (natural killer)Cell Dynamics,
and how we are able (or not) to recover from a viral infection. His experiments were done through out many
years with a research staff with mice and monkeys, mainly mice, and mainly the virus LCMV,
(Lymphocytic Choriomeningitis Virus. LCMV is not a cancer, however it's ideal for the study of cancer and
it's behavior and intricacies.
    The two theories are call Pathways, because of the path that CTL (Cytotoxic T-cell Lymphocyte), may take,
one way or the other, to fight infection. The two theories are;
    CD4_APC_CTL Pathway, and
    Classical Pathway.

    Firstly, using the Woodarz (et al) CD4_APC_CTL Pathway, (cytokines (a signaling protein, a la, a switch);
viz IL2 (interleukin-2)), a simulation is represented here using a tissue mass with suseptible tissue cells to infection.
H_ost cells (the cap 'H') means the H_ost cell is not infected yet, a small 'h' means it was just infected),
v_irus particels ('v's), and CTL white blood cells ('c's) play roles (but not all roles) in this demonstration.
"APC activation" is the principle mechanism for this model. The CD4_APC_CTL Pathway, is a linear model.

     Secondly, The Classical Pathway is a nonlinear one.
     In the Classical Pathway scenario, CD40 + CD40L pair, or B7 + CD28 pair  (or possibly both pairs suggested by some),
 is(are) a signalling process(es), as a product of an immune response, and hopefully virus clearance.

    A frame by frame depiction of H_ost cell vs h_ost cell vs CTL vs v_irus vs K (Killer cell) will be displayed via of
 the program console output.

    If a (healthy) H-ost cell becomes infected, it turns into a small 'h'. If a virus, 'v' comes in close proximity to a H-ost
 cell via natural migration, 'H' becomes 'h'. If and when a virus gets k_illed (K) by a CTL ('c'), the 'v' becomes a 'K'.

    Proximity is also the mechanism for this lysis (devouring the virus to death, as opposed to apoptosis (a programmed
dismantling of the virus particle) ) to occur.

    A blank spot ' ' (char ' '), within the boundary is the remaining organ. It is not suseptible to infection.
 The tissue which contains healthy cells, virus particles, infected cells, white blood cells (lymphocytes (CTL->NK cells))
reside in this organ.

    To summarize the symbology;

 H = (healthy) H_ost cell
 h = infected h_ost
 v = virus or virus particle
 c = CTL/NK (natural killer) cell
 K = killed (the virus is killed)

Initially, the vulnerable tissue sample will of course only be, healthy H_ost cells, randomly.
 |--------|
 |     H  |
 |    H   |
 |H     H |
 |    H   |
 | H   H  |
 |        |
 | H      |
 |  H     |
 |--------|

  Afterwords, v=virus cells, H=healthy H_ost cells, c=CTLs. v infects and c proliferate.
 |--------|
 |v c  H v|
 |v   H c |
 |H    vH |
 |  v H  v|
 | H c H v|
 | v v  v |
 | H v  c |
 |cvHv v v|
 |--------|

 Finally, migration occurs. A v next to a H turns the H into an h. Hopefully a v will be killed by a K.
 |--------|
 |v c H K |
 | v   Kc |
 | hv h h |
 |      v |
 |h  cH v |
 | hvKKH K|
 |   v  cv|
 |cKh   K |
 |--------|


    Using the CD4-APC-CTL interpretation of CTL vs viral population behavior, (Woodarz et al),
 the ratio of virus : CTL =
 3 : 1

    The CD4-APC-CTL version is linear, unlike the Classical version, (still Woodarz et al).

    A Woodarz ~3 : ~1 ratio for CD4-APC-CTL Pathway v : c is depicted frame by frame while the virus particles
 proliferate, but at a 3:1 v:c ratio. As the virus gets lysed, the particle is replaced by a 'K' symbol
 as opposed to mearly having the 'v'disappear.

    If a virus, v, is contiguous or becomes contiguous to a H_ost cell, H, the char 'H' becomes a small
 case char 'h'. This denotes the h_ost cell has become infected.

    If a CTL (cytotoxic T-cell lymphocyte (white blood cell type)), c, is contiguous or becomes contiguous
 to a virus, the virus (v) becomes a char 'K', denoting the virus has been K_illed or rather, lysed.

    Immune cells are also granulocytes. More interesting dynamics are open for implementation for this program,
 and involve much care and minutia. Just a 'nuts and bolts' visual observation of H, h, v->v, v->K and CTL
 are shown here.


 With these populations, the approximate ranges are (very) roughly as follows for either Pathway:
[The H and v distributions are intentionally randomized, spacially]

 The range for v = ~;
 5-16
 The range for h = ~;
 4-12
 The range for H = ~;
 4-8
 The range for c = ~;
 7-15
 The range for K = ~;
 4-14

 >>>                 For the CD4-APC-CTL Pathway -
 the reduction of virus shows to be very roughly;
 ~60%
 The reduction from healthy H_ost to infected h_ost shows to be;
 ~28%
 The kill rate shows to be;
 ~67%
                    CTL prolferation = 0.5v / 1.5
                    ie a 3:1 ratio of virus to CTL.



    The Classical Pathway is also presented. CTL proliferation is exponentially distributed.
The ranges are theoretically more extreme, and clearance is more likely. The temporal order of the
CTL's evolution or "mutation" is;

Precursor (naive) CTL ->
Effector          CTL (We've heard the colloguialism - "White blood cells come to the rescue!") ->
Memory            CTL, ("I never forget a face"). ie eg, the next (nonmutating) strain is mitigated.
The "->" means "differantiate into". The simplified equation is;

                    CTL prolferation = (2 * v^2) / (1 + v)



  The CD4-APC-CTL (linear) Pathway is one of two major studies of Dominic Woodarz - "NK Cell Dynamics;
A Mathematical and Computational Approach to Immunology"  The other is the Classical (nonlinear) Pathway.
  The Classical Pathway, which uses either:

 CD40 + CD40L pair, or,
 B7 + CD28    pair  (or even other pairs as per other theories of other scholars)
 as a product of the immune response.

Both pathways are demonstrated here, and are represented in an Excel graph. Woodarz gets more focused
on other mechanisms and theories including those of HBV, HCB and HIV.




 Notes:    ========================================================================================|

 ---------------------------------------------------------------------|
    It's even believed by some that if an immune response is not Classical, it's the CD4-APC-CTL
 Pathway that yields virus clearance singley. This is conversely true as well.
    Some believe It's both pathways (biphasic) that yield virus resolution or clearance, usually the
 CD4-APC-CTL one first, for the acute phase, followed by the Classical Pathway for the remaining
 chronic (if there in fact the immune repsonse goes that far) phase, until (hopefully) clearance
 of the virus or antigen.

  As per Woodarz "Killer Cell Dynamics - Mathematical and Computational Approaches to Immunology" -
  ISBN 10: 0-387-30893-8 - Page 63 ;
   "The Classical Pathway might be needed if the CTL response needs to expand quickly in the face
of relatively high or increasing virus loads. This can occur, eg if the host gets infected
a second time, and the memory CTL have to react to a grwoing virus population. On the other hand,
the CD4-APC-CTL Pathway could be needed for the CTL to fight the infection efficiencly at low
viral loads. This applies to the resolution phase of the infection, when the CTL have already
reduced virus loads to low levels and need to drive the remaining virus poopulation extinct. If the
CD4-APC-CTL Pathway was not available, modelling suggests that resolution of the infection
is likely to be incomplete: although virus load is initially reduced to low levels, immunological
pressure is lost at low loads, resulting in the ability of the virus popiulation to grow back
and establish a persistent infection."
    The supporting differential equations are on p64.

    This is a nearly ideal condition. Radical cancers like HIV/AIDs, or to a slightly lesser degree,
 Hep-A, B or C, have much different dynamics because they don't follow the Watson-Crick dogma
 (DNA->RNA->protein). ((HIV is a retrovirus, ie RNA->DNA->(killer)protein)).

    For Cell::Infect(); these notes were highlighted:
 INFECT/INVADE BODY. START IMMUNE RESPONSE.
 AFTER ~8 H_ost CELLS SELECTED, -8 + 64(original tissue sample size) = 56 CELLS UNOCCUPIED now.
 AFTER INITIAL INFECTION, 3 v_irus CELLS and 1 CTL WILL BE PRESENT,
 ie THERE WILL BE 4 LESS AVAILABLE CELL SITES TO BE OCCUPIABLE.

    Infect(){} includes the helper function, CTLpopulatesTissue(){} - a recursive function.
 migrate(){} is are initial H_ost cell "movers". It's a sort of primer for cell migration
 to start the predator/prey type process going.

    migrate() and randMigrate() are functions that make cells migrate throughout the tissue.
They call this cell motility. randMigrate() is more realistic. The accomanying Excel spreadsheet
reveals;

    1) Short term CD4-APC-CTL migrate behavior.
    2) Short term CD4-APC-CTL randMigrate behavior.
    3) Long term CD4-APC-CTL migrate behavior.
    4) Long term CD4-APC-CTL randMigrate behavior.
    5) Short term Classical migrate behavior.
    6) Short term Classical randMigrate behavior.
    7) Long term Classical migrate behavior.
    8) Long term Classical randMigrate behavior.

    For CTLpopulatesTissue(){}; these notes were highlighted:

    The CTL proliferation is ~6:~2 (~ 3:1 v:c). The initial possible host vulnerability is:
        20:64 (Sample/tissue size=64).
 Making the probability 10:56(64-8) (deduct the H_ost cell pop), that a CTL will be generated for
 every 3 v_particles.

    FOR EACH CELL (occupied by 'H' or not) ..
 ..THERE SHALL BE A 1/56 (1 CTL IN 63-8) CHANCE OF 1 CTL FOR EVERY 3 VIRUS PARTICLES profiferatiing.
 IF/WHEN THE NUM OF H_ost CELLS ('H') ASSIMILATES THE EMPTY UNOCCUPIED SPACES,
 THAT MEANS, THE VULNERABLILTY (OF INFECTION) INCREASED BY THAT AMOUNT.
 -------------------------------------------------------------------|

    > Intentionally, Cell.h and CellEntity.h have:

 int genericRand();             and
 int betterRand( int n_high, int n_low  ):

    Several good simulations of Biomolecular modelling;
 http://bmm.cancerresearchuk.org/video/index.html
 APC vs T-cell depictions;
 https://images.google.com/   then type;
 "APC cell"

 ==========================================================================================================|
 */

#include "Cell.h"
#include "CellEntity.h"
#include "Virus.h"

#include <cstdlib>
#include <cmath>
#include <ctime>
#include <unistd.h>                                               // sleep()
#include <time.h>

#include <QApplication>
#include "mybox.h"

#include <QWidget>

int main(int argc, char** argv)                                   // Need these args.
{

    QApplication app(argc, argv);

    int someVal=0; int some_i=0; int some_j=0;
    Cell tis;

    Entity* cell[MAX_ROWS][MAX_COLS];

    srand(time(NULL));

    cout<<"\n\t\t\tmain254 Confirming cells initially pointing to NULL.";
    tis.Print();                                                    // virt

    tis.Init();
    tis.Print();

    tis.tissueBoundary();

    tis.populateWithH_ostCells();
    tis.Print();


    MyBox box;                                                      // if/else --> no_go.
    char selection = '1';
    while(selection != NULL) // NULL
    {
        selection = box.showMyBox(app);
        cout<<"\n\nSelection: >>> "<<selection<<endl;
    }
    int sw=0;
    if (selection == '1')
    {
      sw = 0;
    }
    if (selection == '2')
    {
       sw = 1;
    }
    switch (sw) {
        case 0:
            tis.InfectCD4_APC_CTL( someVal, some_i, some_j );       // Woodarz (et al) CD4-APC-CTl Pathway..
            tis.Print();                                            // ..Linear
            break;
        case 1:
            tis.InfectClassical( someVal, some_i, some_j );         // Woodarz (et al) Classical Pathway..
            tis.Print();                                            // ..Nonlinear
            break;
        default:
            cout<<"No selection."<<endl;
            break;
    }



    cout<<"\n\t\t\tmain254  migrate()'ing"<<endl;

    //********//
//  sleep( 1 );                                                     // Optional.
    //********//

//  cout << string(50, '\n');                                       // Optional. Console output.

//  tis.migrate();                                                  // Original cell motility "hard" func.
    tis.randMigrate();                                       // 4-21-15  more realistic cell motility func.

    cout<<"\n\t\t\t\t\tENTITY COUNT >>> "<<endl;
    tis.PrintAndCountEntities();

//  sleep( 5 );                                                     // Optional.

    tis.deallocate(cell);

    cout<<"\n\t\t\t\tE N D"
        <<"\n\t\t\t\tP R O G R A M\n\n";




    return 0;
}












