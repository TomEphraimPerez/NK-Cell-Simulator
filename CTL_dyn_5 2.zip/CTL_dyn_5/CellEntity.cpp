//  CellEntity.cpp
//  CTL_dyn_5
//
//  Created by Thomas Perez on 4/13/15.
//  Copyright (c) 2015 Thomas Perez. All rights reserved.
//

#include "CellEntity.h"
#include <cstdlib>                                              // rand();
#include <ctime>
#include <cmath>
#include <iostream>


using namespace std;

Entity* cell[MAX_ROWS][MAX_COLS];


Entity::Entity(){}                                              // O


Entity::Entity(int coord_i, int coord_j, char the_entity){      /// OOO

    entity = the_entity;

}


Entity::Entity(char the_entity){

    entity = the_entity;
}


bool Entity::isOccupied( int i, int j ){
    int bl = 0;

    if ( cell[i][j]->GetEntity(cell)  == ' ')
        bl = 0;
    else
        bl = 1;

    return bl;
}



char Entity::GetEntity( Entity* cell[MAX_ROWS][MAX_COLS] ) {        // OOO

    if (cell == NULL){
        cout<<"\tEntity54 >>> NULL"<<endl;
        return 99;
    }
    return entity;
}
void Entity::SetEntity(char entity_name){

    entity = entity_name;
}



Entity& Entity::operator = (const Entity& eSource){ // !
    entity = eSource.entity;

    return *this;
}


int Entity::genericRand(){
    float n=0, genRand=0;
    n = rand() % 101 ;

    genRand = static_cast<int>(n/20 -1);                            //yields 0->3.
    // Multiply by useable num for cell size.
    cout<<"\tEntity79 genericRand() "<<genRand<<endl;
    return  (genRand);
}
int Entity::betterRand(int n_high, int n_low){                      // A friend in .cpp

    return (rand() %( n_high - n_low + 1 ) ) + n_low;
}











