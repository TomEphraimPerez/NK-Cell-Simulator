// mybox.cpp
#include "mybox.h"

#include <QVBoxLayout>
#include <iostream>
using namespace std;

#include <QWidget>

MyBox::MyBox()
{
    button1 = new QPushButton("CD4-APC-CTL Pathway");
    button2 = new QPushButton("Classical Pathway");
    label = new QLabel("Press a pathway button. Click the close button(x) afterwords.");

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(button1);
    layout->addWidget(button2);
    layout->addWidget(label);
    setLayout(layout);                                                      // O

    setMinimumSize(200, 100);

  connect(button1, SIGNAL(clicked()), this, SLOT(button1Slot()));          // OOO
  connect(button2, SIGNAL(clicked()), this, SLOT(button2Slot()));

}


MyBox::~MyBox()
{
}

char MyBox::showMyBox(QApplication &app)
{
    selection = NULL;
    this->show();                                                            // O  //.. or just: show();
    app.exec();
    return selection;
}

void MyBox::button1Slot()
{
    cout<<"CD4-APC-CTL"<<endl;
    selection = '1';
    close();                                                                // O  //.. or  this->close()
//  button1 ->hide();     // same as:             connect(button1, SIGNAL(clicked()), this, SLOT(close()));
}

void MyBox::button2Slot()
{
    cout<<"Classical"<<endl;
    selection = '2';
    close();
}

