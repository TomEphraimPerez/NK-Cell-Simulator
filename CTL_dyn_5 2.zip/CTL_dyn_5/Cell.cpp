//  Cell.cpp
//  CTL_dyn_5
//
//  Created by Thomas Perez on 4/13/15.
//  Copyright (c) 2015 Thomas Perez. All rights reserved.
//
#include "Cell.h"
#include <unistd.h> // sleep()
#include "CellEntity.h"
#include <iostream>
#include <math.h>                               // To make CTLpopulatesTissue() more abstract or concise.

Cell::Cell(){
    for (int i=1; i<MAX_ROWS; ++i) {
        for (int j=1; j<MAX_COLS; ++j) {
            cell[i][j] = NULL;                 // *cell is of type Entity and a pointer var.
        }
    }
}


void Cell::Init(){
    for (int i=0; i<MAX_ROWS; i++) {
        for (int j=0; j<MAX_COLS; j++) {
            cell[i][j] = new Entity('x');
        }
    }
}



void Cell::InfectCD4_APC_CTL(int &numOfV_particles,int &i,int &j ){//Call PW_CD4_APC(6); For every 6 v_particles, 2 CTL will respond.
    cout<<"\n\t\t\t>>> Cell33 I N F E C T I N G <<< "<<endl;
    i=0;j=0;                                                // Pre_init.
    numOfV_particles=0;
    // While v_population <= 40/100 * tissue_sample_SIZE.

    for ( i=1; i<MAX_ROWS-1; i++ ) {                         // ITERATE THRU' COMPLETE tissue_sample_SIZE, (initially 100).
        for ( j=1; j<MAX_COLS-1; j++ ) {
            // 25% chance of the ORGAN (not tissue) taking a virus.
            // Tissue: ie the sample H_ost size available for infection.
            int sw=0;
            sw = betterRand( 3, 0 );

            switch (sw) {

                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    if ( cell[i][j]->GetEntity(cell) == 'H' )
                        break;

                    else {
                        cell[i][j]->SetEntity( 'v' );
                        numOfV_particles++;
                        if (numOfV_particles%3==0)
                            CTLpopulatesTissueCD4_APC_CTL( );
                        break;
                    }

                default:
                    cout<<"Cell66 "<<endl;
                    break;
            } // sw
        }  // j
    }   // i
    cout<<"\n\nCell71 Num of viral particles: "<<numOfV_particles<<endl;
}   // void



// Same as y = 0.5x/1.5    ie CTL:v = 1:3
// For every 3 virus particles, one CTL is generated (CTL proliferation) SOMEWHERE in the tissue sample.
// Recursive Fn.
static int f=8; // The possible_infection sample size ' ', not 'H', nor 'h', = 56 (8*8-8), initially. (7*8=56)..
// .. can only have 7*7 (=49). 8 is out of bounds, (0->8).  3:1 = virus particle:CTL.
void Cell::CTLpopulatesTissueCD4_APC_CTL(){

    int numOfCTL=0;
    int i = betterRand( f,1 );                                      // Not ( f,0) !
    int j = betterRand( f,1 );                                      // (7*8=56)

    if( isOccupied( i, j ) == 1 )                                   // Entity::             // If true..
        CTLpopulatesTissueCD4_APC_CTL();
    else {
        cell[i][j]->SetEntity( 'c' );
        numOfCTL++;
    }
    cout<<"\n\nCell91 Num of CTL: "<<numOfCTL<<endl;
} // void




void Cell::InfectClassical(int &numOfV_particles,int &i,int &j ){//Call PW_CD4_APC(6); For every 6 v_particles, 2 CTL will respond.
    cout<<"\n\t\t\t>>> Cell98 I N F E C T I N G <<< "<<endl;
    i=0;j=0;                                                // Pre_init.
    numOfV_particles=0;
    int arbAmount = 8;                                      // 8 virus parts will yield 14.2 CTL
    int numOfCTL = 0;
    // While v_population <= 40/100 * tissue_sample_SIZE.

    for ( i=1; i<MAX_ROWS-1; i++ ) {                         // ITERATE THRU' COMPLETE tissue_sample_SIZE, (initially 100).
        for ( j=1; j<MAX_COLS-1; j++ ) {
            // 25% chance of the ORGAN (not tissue) taking a virus.
            // Tissue: ie the sample H_ost size available for infection.
            int sw=0;
            sw = betterRand( 3, 0 );

            switch (sw) {

                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    if ( cell[i][j]->GetEntity(cell) == 'H' )
                        break;

                    else {
                        cell[i][j]->SetEntity( 'v' );
                        numOfV_particles++;

                        for (int i=0; i<arbAmount; i++) {
                              numOfCTL = floorf( (2 * numOfV_particles ^2) / (1 + numOfV_particles) );
                        }
                        for (int t=0; t<=numOfCTL; t++) {
                              CTLpopulatesTissueClassical();
                        }
                        break;
                    }
                default:
                    cout<<"Cell130 "<<endl;
                    break;
            } // sw
        }  // j
    }   // i
    cout<<"\n\nCell135 Num of viral particles: "<<numOfV_particles<<endl;
}   // void

// Same as y = 2x^2/(1+x)
// Recursive
// CTL ARE generated (CTL proliferation) nonlinearly SOMEWHERE in the tissue sample.
static int g=8;//The possible_infection sample size ' ', not 'H', nor 'h', = 56 (8*8-8), initially. (7*8=56)..
// .. can only have 7*7 (=49). 8 is out of bounds, (0->8).  3:1 = virus particle:CTL.
void Cell::CTLpopulatesTissueClassical(){

    int numOfCTL=0;
    int i = betterRand( f,1 );                                      // Not ( f,0)
    int j = betterRand( f,1 );                                      // (7*8=56)

    if( isOccupied( i, j ) == 1 )                                   // Entity::             // If true..
        CTLpopulatesTissueClassical();
    else {
        cell[i][j]->SetEntity( 'c' );
        numOfCTL++;
    }
    cout<<"\n\nCell161 Num of CTL: "<<numOfCTL<<endl;
} // void




void Cell::populateWithH_ostCells(){        // 10-20:80 cell of the tissue or organ will be vulnerable to infection.
    // (( In this case here, the ratio is ~1:7. APROX 8 (64/8) CELLS = H_osts.
    // AFTER ~8 H_ost CELLS SELECTED, -8 + 64 = 56 CELLS UNOCCUPIED.
    for (int i=1; i<MAX_ROWS-1; i++) {
        for (int j=1; j<MAX_COLS-1; j++) {

            int sw=0;
            sw = betterRand(6, 0);                                  // WRT v and CTL, make H_ost cells ~10:100

            switch (sw){

                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    cell[i][j]->SetEntity( 'H' );
                    break;

                default:
                    cout<<"\n\nCell193 "<<endl;
                    break;
            }
        }
    }
}


// j, y are COLs .                                                  // (Extent of) cellular_tissue_limits_checks included |_|
int i=0; int j=0;

void Cell::Check_moveRT( int x, int y ){

    for (i=1; i<x; i++) {
        for (j=0; j<=y; j++) {

            if(cell[x][y]->GetEntity(cell) == '|')
                break;

            else if (cell[x][y+1]->GetEntity(cell) == ' '){
                *cell[x][y+1] = cell[x][y]->GetEntity(cell);
                cell[x][y]->SetEntity(' ');                         // Set prev cell to new cellular immunity.
            }
        }
    }
}
void Cell::Check_moveLT( int x, int y ){

    for (i=1; i<=x; i++) {
        for (j=0; j<=y; j++) {

            if(cell[x][y]->GetEntity(cell) == '|')                  // ie if the previous position hits the cell limits.
                break;

            else if (cell[x][y-1]->GetEntity(cell) == ' ') {
                *cell[x][y-1] = cell[x][y]->GetEntity(cell);
                cell[x][y]->SetEntity(' ');
            }
        }
    }
}
void Cell::Check_moveDN( int x, int y ){

    for (i=1; i<x; i++) {
        for (j=1; j<y; j++) {

            if(cell[x+1][y]->GetEntity(cell) == '-')
                break;

            else if (cell[x+1][y]->GetEntity(cell) == ' ') {
                *cell[x+1][y] = cell[x][y]->GetEntity(cell);
                cell[x][y]->SetEntity(' ');
            }
        }
    }
}
void Cell::Check_moveUP( int x, int y ){

    for (i=1; i<x; i++) {
        for (j=1; j<y; j++) {

            if(cell[x-1][y]->GetEntity(cell) == '-')
                break;

            else if (cell[x-1][y]->GetEntity(cell) == ' ') {
                *cell[x-1][y] = cell[x][y]->GetEntity(cell);
                cell[x][y]->SetEntity(' ');
            }
        }
    }
}



void Cell::ifVirusKilled() {

    for ( int i=1; i<MAX_ROWS-1; i++ ) {
        for ( int j=1; j<MAX_COLS-1; j++ ) {

            // Re to the current cell being pointed to, and the one to it's       LT  >>>>
            if (      cell[i][j]->GetEntity(cell) == 'v' &&  cell[i][j-1]->GetEntity(cell) == 'c' ) {
                cell[i][j]->SetEntity(  'K');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'c' &&  cell[i][j-1]->GetEntity(cell) == 'v' ) {
                cell[i][j-1]->SetEntity('K');
                continue;
            }

            // Re to the current cell being pointed to, and the one to it's       RT  >>>>
            else if ( cell[i][j]->GetEntity(cell) == 'v' &&  cell[i][j+1]->GetEntity(cell) == 'c' ) {
                cell[i][j]->SetEntity(  'K');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'c' &&  cell[i][j+1]->GetEntity(cell) == 'v' ) {
                cell[i][j+1]->SetEntity('K');
                continue;
            }




            // Re to the current cell being pointed to and the one to it's       ABV   ^^^^
            else if ( cell[i][j]->GetEntity(cell) == 'v' &&  cell[i-1][j]->GetEntity(cell) == 'c' ) {
                cell[i][j]->SetEntity(  'K');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'c' &&  cell[i-1][j]->GetEntity(cell) == 'v' ) {
                cell[i-1][j]->SetEntity('K');         // CAN't BE 'v'
                continue;
            }

            // Seems to work even tho' vert limits are fr 1->8, so that if i=8, 8+1 =9, which is '-'.
            // Re to the current cell being pointed to and the one to it's       BLW   vvvv
            else if ( cell[i][j]->GetEntity(cell) == 'v' &&  cell[i+1][j]->GetEntity(cell) == 'c' ) {
                cell[i][j]->SetEntity(  'K');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'c' &&  cell[i+1][j]->GetEntity(cell) == 'v' ) {
                cell[i+1][j]->SetEntity('K');
                continue;
            }


            else if ( !isalpha ( cell[i][j]->GetEntity(cell) ) )
                continue;
        }
    }
}




// Test adjacency
/**
 eg:
 [h][v] or
 [v]
 [h]
 */
void Cell::ifInfected() {
    // sample size, (in [arr]).

    for ( int i=1; i<MAX_ROWS-1; i++ ) {
        for ( int j=1; j<MAX_COLS-1; j++ ) {

            // v (virus), infects the host cell.     H >>> h.

            // Re to the current cell being pointed to and the one to it's        LT   <<<<
            // 1st 'if' and 1st 'else if' statements appear to be of no consequence.
            //VECTORS ARE PREFERRED.
            if (      cell[i][j]->GetEntity(cell) == 'H' &&  cell[i][j-1]->GetEntity(cell) == 'v' ) {
                cell[i][j]->SetEntity(  'h');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'v' &&  cell[i][j-1]->GetEntity(cell) == 'H' ) {
                cell[i][j-1]->SetEntity('h');
                continue;
            }

            // Re to the current cell being pointed to, and the one to it's       RT  >>>>
            else if ( cell[i][j]->GetEntity(cell) == 'H' &&  cell[i][j+1]->GetEntity(cell) == 'v' ) {
                cell[i][j]->SetEntity(  'h');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'v' &&  cell[i][j+1]->GetEntity(cell) == 'H' ) {
                cell[i][j+1]->SetEntity('h');
                continue;
            }


            // v still infects host cells.         H >>> h


            // Re to the current cell being pointed to and the one to it's       ABV   ^^^^
            else if ( cell[i][j]->GetEntity(cell) == 'H' &&  cell[i-1][j]->GetEntity(cell) == 'v' ) {
                cell[i][j]->SetEntity(  'h');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'v' &&  cell[i-1][j]->GetEntity(cell) == 'H' ) {
                cell[i-1][j]->SetEntity('h');
                continue;
            }

            // Seems to work even tho' vert limits are fr 1->8, so that if i=8, 8+1 =9, which is '-'.
            // Re to the current cell being pointed to and the one to it's       BLW   vvvv
            else if ( cell[i][j]->GetEntity(cell) == 'H' &&  cell[i+1][j]->GetEntity(cell) == 'v' ) {
                cell[i][j]->SetEntity(  'h');
                continue;
            }
            else if ( cell[i][j]->GetEntity(cell) == 'v' &&  cell[i+1][j]->GetEntity(cell) == 'H' ) {
                cell[i+1][j]->SetEntity('h');
                continue;
            }


            else if ( !isalpha ( cell[i][j]->GetEntity(cell) ) )
                continue;
        }
    }
}




void Cell::randMigrate(){
    Check_moveSWITCH( 1, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH( 2, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH( 3, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH( 4, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH( 5, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH( 6, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH( 7, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH( 8, betterRand( 8, 1) );
    ifInfected();
    ifVirusKilled();
}



void Cell::migrate(){
    Check_moveSWITCH(1,1);  //0
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(1,6);  //1
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(1,8);  //2
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(2,1);  //3
    ifInfected();
    ifVirusKilled();
    //    cout << string(50, '\n');                    //Option. Don't care to see TMI in console o/p.

    Check_moveSWITCH(2,5);  //4
    ifInfected();
    ifVirusKilled();
    Check_moveRT(3,1);                                 // Priming activity.

    Check_moveSWITCH(3,1);  //5
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(3,6);  //6
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(4,3);  //7
    ifInfected();
    ifVirusKilled();
    //    cout << string(50, '\n');

    Check_moveSWITCH(4,5);  //8
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(4,8);  //9
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(5,2);  //10
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(5,6);  //11
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(5,8);  //12
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(6,2);  //13
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(6,4);  //14
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(6,7);  //15
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(7,2);  //16
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(7,4);  //17
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(8,4);  //18
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(8,6);  //19
    ifInfected();
    ifVirusKilled();

    Check_moveSWITCH(8,8);  //20
    ifInfected();
    ifVirusKilled();
}



const void Cell::Check_moveSWITCH(int x, int y)  {

    int SW=0;
    int count=0;

  while (count< 8)  {                      // < 1min.
//  while (count< 16)   {
//  while (count< 24)   {
//  while (count< 48)   {
//  while (count< 96)   {
//  while (count< 192)  {
//  while (count< 384)  {
//  while (count< 786)  {
//  while (count< 1536) {                  // <<<   <<<  CD4-APC-CTl takes 2hr43min.
                                         // <<<   <<<  Classical   takes 1hr03min.
//  while (count< 3072) {                                           // ok 4-24-15)0000

        SW = genericRand();

        switch (SW) {

            case 0:
                Check_moveLT(x,  y);
                break;
            case 1:
                Check_moveRT(x,   y);
                break;
            case 2:
                Check_moveUP(x,  y);
                break;
            case 3:
                Check_moveDN(x,  y);
                break;
            default:
                break;
        }
        count++;
        Print();            // Intentional print inside a function for frame-to-frame depictions of cell
        // entity movement. This is similar to the animated card deck
        // showing (eg) someone riding a bicycle or jugling...
        usleep(USLEEP);
    }
}



int Cell::genericRand(){
    float n=0, genRand=0;
    n = rand() % 101 ;
    genRand = static_cast<int>(n/20 -1);                                // CHK yields 0->3.

    return  (genRand);
}
int Cell::betterRand( int n_high, int n_low ){

    return ( rand()%(n_high - n_low + 1) ) + n_low;
}




void Cell::Print(){

    for (int i=0; i<MAX_ROWS; i++) {
        for (int j=0; j<MAX_COLS; j++) {

            if (cell[i][j] == NULL)
                cout<<"\n\t\t\tCell558 Pointing to NULL."<<endl;

            else
                cout << cell[i][j]->GetEntity(cell);
        }
        cout<<endl;
    }
}
void Cell::PrintAndCountEntities(){

    int H_count=0, h_count=0, v_count=0, c_count=0, K_count=0;
    for (int i=0; i<MAX_ROWS; i++) {
        for (int j=0; j<MAX_COLS; j++) {

            if (cell[i][j] == NULL)
                cout<<"\n\t\t\tCell573 Pointing to NULL."<<endl;

            else if ( cell[i][j]->GetEntity(cell) == 'H')
                H_count++;
            else if ( cell[i][j]->GetEntity(cell) == 'h')
                h_count++;
            else if ( cell[i][j]->GetEntity(cell) == 'v')
                v_count++;
            else if ( cell[i][j]->GetEntity(cell) == 'c')
                c_count++;
            else if ( cell[i][j]->GetEntity(cell) == 'K')
                K_count++;

        }
//      cout<<endl;
    }
     cout<<"\nH_count: "<<H_count<<endl;
     cout<<"\nh_count: "<<h_count<<endl;
     cout<<"\nv_count: "<<v_count<<endl;
     cout<<"\nc_count: "<<c_count<<endl;
     cout<<"\nK_count: "<<K_count<<endl;
}



ostream& operator << ( ostream& out_stream, const Cell& theCell ){

    out_stream << theCell;

    return out_stream;
}



void Cell::deallocate(Entity* cell[][MAX_COLS]){

    int i=0, j=0;
    for (i=0; i<MAX_ROWS; i++){
        for(j=0; j<MAX_COLS; j++){

            cell[i][j]=NULL;
            delete  cell[i][j];
        }
    }
}



void Cell::tissueBoundary(){ // This is the organ or tissue (different) limit of possible infection.

    cell[0][0] = new Entity('|');    cell[1][0] = new Entity('|');
    cell[0][1] = new Entity('-');    cell[1][1] = new Entity(' ');
    cell[0][2] = new Entity('-');    cell[1][2] = new Entity(' ');
    cell[0][3] = new Entity('-');    cell[1][3] = new Entity(' ');
    cell[0][4] = new Entity('-');    cell[1][4] = new Entity(' ');
    cell[0][5] = new Entity('-');    cell[1][5] = new Entity(' ');
    cell[0][6] = new Entity('-');    cell[1][6] = new Entity(' ');
    cell[0][7] = new Entity('-');    cell[1][7] = new Entity(' ');
    cell[0][8] = new Entity('-');    cell[1][8] = new Entity(' ');
    cell[0][9] = new Entity('|');    cell[1][9] = new Entity('|');

    cell[2][0] = new Entity('|');    cell[3][0] = new Entity('|');
    cell[2][1] = new Entity(' ');    cell[3][1] = new Entity(' ');
    cell[2][2] = new Entity(' ');    cell[3][2] = new Entity(' ');
    cell[2][3] = new Entity(' ');    cell[3][3] = new Entity(' ');
    cell[2][4] = new Entity(' ');    cell[3][4] = new Entity(' ');
    cell[2][5] = new Entity(' ');    cell[3][5] = new Entity(' ');
    cell[2][6] = new Entity(' ');    cell[3][6] = new Entity(' ');
    cell[2][7] = new Entity(' ');    cell[3][7] = new Entity(' ');
    cell[2][8] = new Entity(' ');    cell[3][8] = new Entity(' ');
    cell[2][9] = new Entity('|');    cell[3][9] = new Entity('|');

    cell[4][0] = new Entity('|');    cell[5][0] = new Entity('|');
    cell[4][1] = new Entity(' ');    cell[5][1] = new Entity(' ');
    cell[4][2] = new Entity(' ');    cell[5][2] = new Entity(' ');
    cell[4][3] = new Entity(' ');    cell[5][3] = new Entity(' ');
    cell[4][4] = new Entity(' ');    cell[5][4] = new Entity(' ');
    cell[4][5] = new Entity(' ');    cell[5][5] = new Entity(' ');
    cell[4][6] = new Entity(' ');    cell[5][6] = new Entity(' ');
    cell[4][7] = new Entity(' ');    cell[5][7] = new Entity(' ');
    cell[4][8] = new Entity(' ');    cell[5][8] = new Entity(' ');
    cell[4][9] = new Entity('|');    cell[5][9] = new Entity('|');

    cell[6][0] = new Entity('|');    cell[7][0] = new Entity('|');
    cell[6][1] = new Entity(' ');    cell[7][1] = new Entity(' ');
    cell[6][2] = new Entity(' ');    cell[7][2] = new Entity(' ');
    cell[6][3] = new Entity(' ');    cell[7][3] = new Entity(' ');
    cell[6][4] = new Entity(' ');    cell[7][4] = new Entity(' ');
    cell[6][5] = new Entity(' ');    cell[7][5] = new Entity(' ');
    cell[6][6] = new Entity(' ');    cell[7][6] = new Entity(' ');
    cell[6][7] = new Entity(' ');    cell[7][7] = new Entity(' ');
    cell[6][8] = new Entity(' ');    cell[7][8] = new Entity(' ');
    cell[6][9] = new Entity('|');    cell[7][9] = new Entity('|');

    cell[8][0] = new Entity('|');    cell[9][0] = new Entity('|');
    cell[8][1] = new Entity(' ');    cell[9][1] = new Entity('-');
    cell[8][2] = new Entity(' ');    cell[9][2] = new Entity('-');
    cell[8][3] = new Entity(' ');    cell[9][3] = new Entity('-');
    cell[8][4] = new Entity(' ');    cell[9][4] = new Entity('-');
    cell[8][5] = new Entity(' ');    cell[9][5] = new Entity('-');
    cell[8][6] = new Entity(' ');    cell[9][6] = new Entity('-');
    cell[8][7] = new Entity(' ');    cell[9][7] = new Entity('-');
    cell[8][8] = new Entity(' ');    cell[9][8] = new Entity('-');
    cell[8][9] = new Entity('|');    cell[9][9] = new Entity('|');

    cout<<"\n\tCell644 cell[x][y] = new Entity(i,j, 'entity') >>> "<<endl;
    for (int i=0; i<MAX_ROWS; i++){
        for (int j=0; j<MAX_COLS; j++){
            cout<<"["<<i<<"]"<<"]["<<j<<"]="<<cell[i][j]->GetEntity(cell)<<" ";
        }
        cout<<endl;
    }
    int numOfAches=0;
    for (int i=0; i<MAX_ROWS; i++){
        for (int j=0; j<MAX_COLS; j++){

            if ( cell[i][j]->GetEntity(cell) == 'H')
                numOfAches+=numOfAches;
            // cout<<"Number of healthy H_ost cells: "<<numOfAches<<endl;
        }
        cout<<endl;
    }
    int numOfVees=0;
    for (int i=0; i<MAX_ROWS; i++){
        for (int j=0; j<MAX_COLS; j++){

            if ( cell[i][j]->GetEntity(cell) == 'v')
                numOfVees+=numOfVees;
            // cout<<"Number of v_irus particles (virions): "<<numOfVees<<endl;
        }
        cout<<endl;
    }
}









