// mybox.h
#ifndef MYBOX_H
#define MYBOX_H

#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QLabel>

class MyBox : public QWidget
{
    Q_OBJECT // pvt

public:
    MyBox();
    ~MyBox();



    char showMyBox(QApplication &app);

private slots:
    void button1Slot();
    void button2Slot();

private:
    QPushButton *button1;
    QPushButton *button2;
    QLabel *label;

    char selection;


};

#endif // MYBOX_H
