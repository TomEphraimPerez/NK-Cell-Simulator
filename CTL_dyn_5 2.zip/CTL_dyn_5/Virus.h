//  Virus.h
//  CTL_dyn_5
//
//  Created by Thomas Perez on 4/13/15.
//  Copyright (c) 2015 Thomas Perez. All rights reserved.

#ifndef __CTL_dyn_5__Virus__
#define __CTL_dyn_5__Virus__



#include <iostream>
#include "CONSTANTS.h"
#include "CellEntity.h"
#include "Cell.h"
#include <math.h>


class Virus : public Entity {

public:


    Virus();

    float PW_CD4_APC( float );
    float PW_C( float );

    void Proliferate();                            // .. at a specific rate given predetermined values. Wodarz p59-62
    void Die();                                    // .. at a specific rate given predetermined values. Wodarz p59-62
    void KillImmuneCell();    // DITTO as above +  Replace occupied ImmuneCell pos.


protected:



private:

    //     float y = 1.0;                               // APC population,(p59).
    //
    //     float z;                                     // CTL proliferation (factor, AOT prolif rate). ((as opposed to))
    //     float x;                                     // T_helper_free count, (p58)
    //
    //     float gamma, eta;                            // reaction constants, (p62).
    //     float c;                                     // net CTL activation reaction const.      AKA CTL_responsiveness.
    //     float epsilon;                               // net APC activation reaction const (p59),
    // or efficacy of help(p60)

};

#endif /* defined(__CTL_dyn_5__Virus__) */





